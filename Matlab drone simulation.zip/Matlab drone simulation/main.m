
plot3(out.PositionVector(:,1),out.PositionVector(:,2),out.PositionVector(:,3),'r');
xlabel('x');
ylabel('y');
zlabel('z');
set(gca,'YDIR','reverse');
set(gca,'ZDIR','reverse');